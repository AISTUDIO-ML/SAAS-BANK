#!/bin/bash
# Delete AWS S3 sandbox bucket and its contents
BUCKET_NAME="saas-bank-frontend-sandbox"

echo "Deleting all objects in S3 bucket: $BUCKET_NAME"
aws s3 rm s3://$BUCKET_NAME --recursive

echo "Deleting S3 bucket: $BUCKET_NAME"
aws s3 rb s3://$BUCKET_NAME
