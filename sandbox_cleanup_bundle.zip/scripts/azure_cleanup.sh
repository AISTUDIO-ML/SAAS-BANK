#!/bin/bash
# Delete Azure sandbox resource group
RESOURCE_GROUP="saas-bank-backend-sandbox"

echo "Deleting Azure resource group: $RESOURCE_GROUP"
az group delete --name $RESOURCE_GROUP --yes --no-wait
