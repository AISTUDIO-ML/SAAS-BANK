# Sandbox Cleanup and Cost Monitoring

## Cleanup Scripts

- `scripts/aws_cleanup.sh`: Deletes AWS S3 sandbox bucket and contents.
- `scripts/azure_cleanup.sh`: Deletes Azure sandbox resource group.

## GitHub Actions Workflows

- `.github/workflows/aws_cleanup.yml`: Manually triggered AWS cleanup.
- `.github/workflows/azure_cleanup.yml`: Manually triggered Azure cleanup.

## Cost Monitoring Best Practices

### AWS
- Use **AWS Budgets** to set cost thresholds and alerts.
- Enable **Cost Explorer** for detailed usage insights.
- Use **resource tagging** to track sandbox resources.

### Azure
- Use **Azure Cost Management + Billing** to monitor spending.
- Set **budgets and alerts** for sandbox resource groups.
- Use **tags** to identify and filter sandbox resources.

