# Real-Time Metrics Tracking for Sandbox Cleanup

This bundle enables Prometheus and Grafana integration for monitoring sandbox cleanup jobs.

## Setup Instructions

### Prometheus

1. Install Prometheus.
2. Use `prometheus/prometheus.yml` as your configuration file.
3. Ensure the cleanup job exposes metrics to Prometheus Pushgateway.

### Grafana

1. Import `grafana/sandbox_cleanup_dashboard.json` into Grafana.
2. Set Prometheus as the data source.
3. Visualize cleanup duration and job status.

### GitHub Actions

- Use `github_workflows/aws_cleanup_metrics.yml` to schedule cleanup and push metrics.
- Ensure Prometheus Pushgateway is accessible from the runner.

## Metrics

- `sandbox_cleanup_duration_seconds`: Duration of cleanup job in seconds.