#!/bin/bash

# Variables
BUCKET_NAME="saas-bank-frontend"
REGION="us-east-1"
BUILD_DIR="build"

# Build the React app
echo "Installing dependencies and building the React app..."
npm install
npm run build

# Create S3 bucket if it doesn't exist
echo "Creating S3 bucket if it doesn't exist..."
aws s3 mb s3://$BUCKET_NAME --region $REGION || echo "Bucket already exists."

# Enable static website hosting
echo "Enabling static website hosting..."
aws s3 website s3://$BUCKET_NAME/ --index-document index.html --error-document index.html

# Upload build files to S3
echo "Uploading build files to S3..."
aws s3 sync $BUILD_DIR/ s3://$BUCKET_NAME/ --delete

# Create bucket policy
echo "Applying public-read bucket policy..."
cat <<EOF > policy.json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublicReadGetObject",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::$BUCKET_NAME/*"
    }
  ]
}
EOF

aws s3api put-bucket-policy --bucket $BUCKET_NAME --policy file://policy.json
rm policy.json

# Output website URL
echo "Deployment complete."
echo "Website URL: http://$BUCKET_NAME.s3-website-$REGION.amazonaws.com"
