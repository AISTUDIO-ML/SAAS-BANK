# Azure TEE Backend Deployment

This package contains a GitHub Actions workflow for deploying a backend to Azure using a custom role for Trusted Execution Environment (TEE).

## 🔐 Required GitHub Secrets

| Secret Name             | Description                                |
|-------------------------|--------------------------------------------|
| AZURE_CLIENT_ID         | Client ID of the Azure service principal   |
| AZURE_TENANT_ID         | Tenant ID of your Azure AD                 |
| AZURE_SUBSCRIPTION_ID   | Azure subscription ID                      |
| AZURE_RESOURCE_GROUP    | Resource group for deployment              |

## 📄 Custom Role

Ensure the service principal has a custom role with permissions to deploy Confidential VMs, manage networking, and access Key Vault.

## 🚀 Deployment

Push to the `main` branch to trigger the workflow and deploy the backend to Azure.

## 📁 Files

- `.github/workflows/deploy_azure_tee.yml`: GitHub Actions workflow
- `README.md`: This file
