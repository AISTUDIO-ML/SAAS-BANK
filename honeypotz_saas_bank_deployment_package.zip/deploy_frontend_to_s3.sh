#!/bin/bash
set -e

BUCKET_NAME="saas-bank-frontend"

echo "Installing dependencies and building React app..."
npm install
npm run build

echo "Creating S3 bucket if it doesn't exist..."
aws s3 mb s3://$BUCKET_NAME --region us-east-1 || true

echo "Enabling static website hosting..."
aws s3 website s3://$BUCKET_NAME/ --index-document index.html --error-document index.html

echo "Uploading build files to S3..."
aws s3 sync build/ s3://$BUCKET_NAME/ --delete

echo "Applying public-read bucket policy..."
cat <<EOF > policy.json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublicReadGetObject",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3://$BUCKET_NAME/*"
    }
  ]
}
EOF

aws s3api put-bucket-policy --bucket $BUCKET_NAME --policy file://policy.json
rm policy.json

echo "Deployment complete. Site URL:"
echo "http://$BUCKET_NAME.s3-website-us-east-1.amazonaws.com"
