#!/bin/bash
set -e
BUCKET_NAME=saas-bank-frontend
REGION=us-east-1

npm install
npm run build

aws s3 mb s3://$BUCKET_NAME --region $REGION || true
aws s3 website s3://$BUCKET_NAME/ --index-document index.html --error-document index.html
aws s3 sync build/ s3://$BUCKET_NAME/ --delete

cat <<EOF > policy.json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublicReadGetObject",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::$BUCKET_NAME/*"
    }
  ]
}
EOF

aws s3api put-bucket-policy --bucket $BUCKET_NAME --policy file://policy.json
echo "Frontend deployed to http://$BUCKET_NAME.s3-website-$REGION.amazonaws.com"
