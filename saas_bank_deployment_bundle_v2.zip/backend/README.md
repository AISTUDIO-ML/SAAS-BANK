# Azure TEE Backend Deployment

## GitHub Secrets Required

- `AZURE_CREDENTIALS`: JSON output from `az ad sp create-for-rbac`
- `AZURE_RESOURCE_GROUP`: Name of the resource group

## Custom Role

Use `tee_backend_custom_role.json` to create a least-privilege role.

## Deployment

This workflow deploys backend infrastructure using Bicep to Azure TEE.
